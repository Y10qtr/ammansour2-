const prompt = require('prompt-sync')()
const business = require('./business')

/**
 * Display all employees in a friendly formatted table in the console.
 * @returns {Promise<void>}
 */
async function showEmployees() {
    let list = await business.getAllEmployees()

    console.log("Employee ID   Name                Phone")
    console.log("------------  ------------------  ---------")

    for (let i = 0; i < list.length; i++) {
        console.log(
            list[i].employeeId.padEnd(13) +
            list[i].name.padEnd(20) +
            list[i].phone
        )
    }
}

/**
 * Prompt the user for employee details and add the new employee.
 * @returns {Promise<void>}
 */
async function addEmployeeUI() {
    let name = prompt("Enter employee name: ")
    let phone = prompt("Enter phone: ")

    await business.addEmployee({ name: name, phone: phone })

    console.log("Employee added.")
}

/**
 * Prompt the user for employeeId and shiftId and attempt to assign the shift.
 * Displays a friendly success or error message.
 * @returns {Promise<void>}
 */
async function scheduleEmployeeUI() {
    let empId = prompt("Enter employee ID: ")
    let shiftId = prompt("Enter shift ID: ")

    let result = await business.assignShift(empId, shiftId)

    if (result === "Ok") {
        console.log("Shift recorded.")
    } else {
        console.log(result)
    }
}

/**
 * Prompt for an employeeId and display a friendly table of their scheduled shifts.
 * Shows shift details (date/start/end) and computed hours.
 * @returns {Promise<void>}
 */
async function showScheduleUI() {
    let empId = prompt("Enter employee ID: ")

    let result = await business.getEmployeeScheduleDetails(empId)

    if (result.error) {
        console.log(result.error)
        return
    }

    console.log("\nSchedule for: " + result.employee.name + " (" + result.employee.employeeId + ")")
    console.log("Shift ID   Date         Start   End     Hours")
    console.log("--------   ----------   -----   -----   -----")

    let total = 0

    for (let i = 0; i < result.details.length; i++) {
        let d = result.details[i]
        total += d.hours

        console.log(
            d.shiftId.padEnd(10) +
            d.date.padEnd(13) +
            d.startTime.padEnd(8) +
            d.endTime.padEnd(8) +
            String(d.hours).padEnd(5)
        )
    }

    console.log("\nTotal Hours: " + total)
}

/**
 * Display the main menu loop and call UI actions based on user selection.
 * @returns {Promise<void>}
 */
async function menu() {
    while (true) {
        console.log("\n1. Show Employees")
        console.log("2. Add Employee")
        console.log("3. Assign Shift")
        console.log("4. View Schedule")
        console.log("5. Exit")

        let choice = Number(prompt("Choice: "))

        if (choice === 1) {
            await showEmployees()
        } else if (choice === 2) {
            await addEmployeeUI()
        } else if (choice === 3) {
            await scheduleEmployeeUI()
        } else if (choice === 4) {
            await showScheduleUI()
        } else if (choice === 5) {
            break
        } else {
            console.log("Invalid choice")
        }
    }

    console.log("Goodbye")
}

menu()