const persistence = require('./persistence')

/**
 * LLM Used: ChatGPT (GPT-5)
 * Prompt:
 * "Write a JavaScript function computeShiftDuration(startTime, endTime)
 * where times are HH:MM format and return hours as a decimal number."
 *
 * Compute the number of hours between a shift start and end time (HH:MM -> decimal hours).
 * Example: "11:00" to "13:30" returns 2.5
 * @param {string} startTime - HH:MM (24-hour)
 * @param {string} endTime - HH:MM (24-hour)
 * @returns {number} hours as a real number
 */
function computeShiftDuration(startTime, endTime) {
    let startParts = startTime.split(':')
    let endParts = endTime.split(':')

    let startMinutes = Number(startParts[0]) * 60 + Number(startParts[1])
    let endMinutes = Number(endParts[0]) * 60 + Number(endParts[1])

    let diff = endMinutes - startMinutes
    return diff / 60
}

/**
 * Assign a shift to an employee while enforcing business rules:
 * - employee must exist
 * - shift must exist
 * - assignment must not already exist
 * - total hours for that employee on that date must not exceed config.json maxDailyHours
 * @param {string} empId
 * @param {string} shiftId
 * @returns {Promise<string>} "Ok" or an error message
 */
async function assignShift(empId, shiftId) {
    let employee = await persistence.findEmployee(empId)
    if (!employee) {
        return "Employee does not exist"
    }

    let shift = await persistence.findShift(shiftId)
    if (!shift) {
        return "Shift does not exist"
    }

    let existing = await persistence.findAssignment(empId, shiftId)
    if (existing) {
        return "Employee already assigned to shift"
    }

    // ----- DAILY LIMIT CHECK -----
    let assignments = await persistence.getAssignmentsForEmployee(empId)
    let allShifts = await persistence.getAllShifts()

    let totalHours = 0

    // sum existing hours for same date
    for (let i = 0; i < assignments.length; i++) {
        let asn = assignments[i]

        for (let j = 0; j < allShifts.length; j++) {
            let sh = allShifts[j]
            if (sh.shiftId === asn.shiftId && sh.date === shift.date) {
                totalHours += computeShiftDuration(sh.startTime, sh.endTime)
                break
            }
        }
    }

    // add new shift hours
    totalHours += computeShiftDuration(shift.startTime, shift.endTime)

    let maxHours = await persistence.getMaxDailyHours()

    if (totalHours > maxHours) {
        return "Daily hour limit exceeded"
    }

    await persistence.addAssignment(empId, shiftId)
    return "Ok"
}

/**
 * Build a detailed schedule for an employee by joining assignments.json with shifts.json.
 * Returns friendly shift details (date/start/end) plus computed hours.
 * @param {string} empId
 * @returns {Promise<{error: string|null, employee: {employeeId:string,name:string,phone:string}|undefined, details: Array<{shiftId:string,date:string,startTime:string,endTime:string,hours:number}>}>}
 */
async function getEmployeeScheduleDetails(empId) {
    let employee = await persistence.findEmployee(empId)
    if (!employee) {
        return { error: "Employee does not exist", employee: undefined, details: [] }
    }

    let assignments = await persistence.getAssignmentsForEmployee(empId)
    let allShifts = await persistence.getAllShifts()

    let details = []

    for (let i = 0; i < assignments.length; i++) {
        let shiftId = assignments[i].shiftId

        for (let j = 0; j < allShifts.length; j++) {
            let sh = allShifts[j]
            if (sh.shiftId === shiftId) {
                let hours = computeShiftDuration(sh.startTime, sh.endTime)
                details.push({
                    shiftId: sh.shiftId,
                    date: sh.date,
                    startTime: sh.startTime,
                    endTime: sh.endTime,
                    hours: hours
                })
                break
            }
        }
    }

    return { error: null, employee: employee, details: details }
}

/**
 * Return all employees (passthrough to persistence layer).
 * @returns {Promise<Array<{employeeId:string, name:string, phone:string}>>}
 */
async function getAllEmployees() {
    return await persistence.getAllEmployees()
}

/**
 * Add a new employee (passthrough to persistence layer).
 * @param {{name:string, phone:string}} emp
 * @returns {Promise<void>}
 */
async function addEmployee(emp) {
    await persistence.addEmployee(emp)
}

/**
 * Get all assignments for an employeeId (passthrough to persistence layer).
 * @param {string} empId
 * @returns {Promise<Array<{employeeId:string, shiftId:string}>>}
 */
async function getAssignmentsForEmployee(empId) {
    return await persistence.getAssignmentsForEmployee(empId)
}

/**
 * Find a shift by shiftId (passthrough to persistence layer).
 * @param {string} shiftId
 * @returns {Promise<{shiftId:string, date:string, startTime:string, endTime:string}|undefined>}
 */
async function findShift(shiftId) {
    return await persistence.findShift(shiftId)
}

module.exports = {
    assignShift,
    computeShiftDuration,
    getEmployeeScheduleDetails,
    getAllEmployees,
    addEmployee,
    getAssignmentsForEmployee,
    findShift
}