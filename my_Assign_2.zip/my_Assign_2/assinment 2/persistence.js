const fs = require('fs/promises')

// ---------- EMPLOYEES ----------

/**
 * Load and return the full list of employees from employees.json.
 * @returns {Promise<Array<{employeeId:string, name:string, phone:string}>>}
 */
async function getAllEmployees() {
    let raw = await fs.readFile('employees.json', 'utf8')
    return JSON.parse(raw)
}

/**
 * Find and return one employee by employeeId, or undefined if not found.
 * @param {string} empId - Employee ID (example: "E001")
 * @returns {Promise<{employeeId:string, name:string, phone:string}|undefined>}
 */
async function findEmployee(empId) {
    let raw = await fs.readFile('employees.json', 'utf8')
    let list = JSON.parse(raw)

    for (let i = 0; i < list.length; i++) {
        if (list[i].employeeId === empId) {
            return list[i]
        }
    }
    return undefined
}

/**
 * Add a new employee record to employees.json.
 * Automatically generates the next employeeId in the format Exxx.
 * @param {{name:string, phone:string}} emp - New employee info (no employeeId yet)
 * @returns {Promise<void>}
 */
async function addEmployee(emp) {
    let raw = await fs.readFile('employees.json', 'utf8')
    let list = JSON.parse(raw)

    let maxId = 0
    for (let i = 0; i < list.length; i++) {
        let num = Number(list[i].employeeId.slice(1))
        if (num > maxId) {
            maxId = num
        }
    }

    emp.employeeId = "E" + String(maxId + 1).padStart(3, '0')
    list.push(emp)

    await fs.writeFile('employees.json', JSON.stringify(list, null, 4))
}

// ---------- SHIFTS ----------

/**
 * Find and return one shift by shiftId, or undefined if not found.
 * @param {string} shiftId - Shift ID (example: "S001")
 * @returns {Promise<{shiftId:string, date:string, startTime:string, endTime:string}|undefined>}
 */
async function findShift(shiftId) {
    let raw = await fs.readFile('shifts.json', 'utf8')
    let list = JSON.parse(raw)

    for (let i = 0; i < list.length; i++) {
        if (list[i].shiftId === shiftId) {
            return list[i]
        }
    }
    return undefined
}

/**
 * Load and return the full list of shifts from shifts.json.
 * @returns {Promise<Array<{shiftId:string, date:string, startTime:string, endTime:string}>>}
 */
async function getAllShifts() {
    let raw = await fs.readFile('shifts.json', 'utf8')
    return JSON.parse(raw)
}

// ---------- ASSIGNMENTS ----------

/**
 * Find and return one assignment record for a specific employeeId + shiftId pair.
 * @param {string} empId
 * @param {string} shiftId
 * @returns {Promise<{employeeId:string, shiftId:string}|undefined>}
 */
async function findAssignment(empId, shiftId) {
    let raw = await fs.readFile('assignments.json', 'utf8')
    let list = JSON.parse(raw)

    for (let i = 0; i < list.length; i++) {
        if (list[i].employeeId === empId &&
            list[i].shiftId === shiftId) {
            return list[i]
        }
    }
    return undefined
}

/**
 * Add a new assignment record to assignments.json (no validation here).
 * NOTE: Business layer should ensure no duplicates and rules are respected.
 * @param {string} empId
 * @param {string} shiftId
 * @returns {Promise<void>}
 */
async function addAssignment(empId, shiftId) {
    let raw = await fs.readFile('assignments.json', 'utf8')
    let list = JSON.parse(raw)

    list.push({ employeeId: empId, shiftId: shiftId })

    await fs.writeFile('assignments.json', JSON.stringify(list, null, 4))
}

/**
 * Return all assignment records for a given employeeId.
 * @param {string} empId
 * @returns {Promise<Array<{employeeId:string, shiftId:string}>>}
 */
async function getAssignmentsForEmployee(empId) {
    let raw = await fs.readFile('assignments.json', 'utf8')
    let list = JSON.parse(raw)

    let result = []
    for (let i = 0; i < list.length; i++) {
        if (list[i].employeeId === empId) {
            result.push(list[i])
        }
    }

    return result
}

/**
 * Read config.json and return the maxDailyHours limit used by the system.
 * @returns {Promise<number>}
 */
async function getMaxDailyHours() {
    let raw = await fs.readFile('config.json', 'utf8')
    let config = JSON.parse(raw)
    return config.maxDailyHours
}

module.exports = {
    getAllEmployees,
    findEmployee,
    addEmployee,
    findShift,
    getAllShifts,
    findAssignment,
    addAssignment,
    getAssignmentsForEmployee,
    getMaxDailyHours
}