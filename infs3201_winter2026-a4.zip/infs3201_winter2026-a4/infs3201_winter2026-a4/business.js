const persistence = require('./persistence-mongodb.js')

/**
 * Return a list of all employees loaded from the storage.
 * @returns {Promise<Array<{ employeeId: string, name: string, phone: string }>>}
 */
async function getAllEmployees() {
    return await persistence.getAllEmployees()
}

/**
 * Get a list of shift details for an employee.
 * @param {string} empId 
 * @returns {Promise<Array<{shiftId:string, date:string, startTime:string, endTime:string}>>}
 */
async function getEmployeeShifts(empId) {
    return await persistence.getEmployeeShifts(empId)
}

/**
 * Add a new employee record to the system.
 * @param {{name:string, phone:string}} emp 
 * @returns {Promise<{employeeId: string, name: string, phone: string}>}
 */
async function addEmployeeRecord(emp) {
    return await persistence.addEmployeeRecord(emp)
}

/**
 * Get employee by ID
 * @param {string} empId 
 * @returns {Promise<{employeeId: string, name: string, phone: string}|null>}
 */
async function getEmployeeById(empId) {
    return await persistence.findEmployee(empId)
}

/**
 * Update an employee record
 * @param {string} empId 
 * @param {{name: string, phone: string}} empData 
 * @returns {Promise<boolean>}
 */
async function updateEmployee(empId, empData) {
    return await persistence.updateEmployee(empId, empData)
}

/**
 * Initialize the database with sample data
 * @returns {Promise<void>}
 */
async function initializeDatabase() {
    return await persistence.initializeDatabase()
}

module.exports = {
    getAllEmployees, addEmployeeRecord, getEmployeeShifts,
    getEmployeeById, updateEmployee, initializeDatabase
}