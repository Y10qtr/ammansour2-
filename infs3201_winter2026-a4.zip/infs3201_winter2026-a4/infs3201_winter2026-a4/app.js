const express = require('express')
const { engine } = require('express-handlebars')
const business = require('./business.js')
const handlebarsHelpers = require('./helpers/handlebars-helpers.js')

const app = express()
const PORT = process.env.PORT || 3000

/**
 * Configure Handlebars as the view engine
 */
app.engine('handlebars', engine({ helpers: handlebarsHelpers }))
app.set('view engine', 'handlebars')
app.set('views', './views')

/**
 * Middleware
 */
app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'))

/**
 * Landing page - List all employees
 * @route GET /
 */
app.get('/', async (req, res) => {
    try {
        const employees = await business.getAllEmployees()
        res.render('home', { employees })
    } catch (error) {
        res.status(500).send('Error loading employees: ' + error.message)
    }
})

/**
 * Employee details page
 * @route GET /employees/:empId
 */
app.get('/employees/:empId', async (req, res) => {
    try {
        const empId = req.params.empId
        const employee = await business.getEmployeeById(empId)
        
        if (!employee) {
            return res.status(404).send('Employee not found')
        }
        
        const shifts = await business.getEmployeeShifts(empId)
        
        res.render('employee-details', { employee, shifts })
    } catch (error) {
        res.status(500).send('Error loading employee details: ' + error.message)
    }
})

/**
 * Edit employee form
 * @route GET /employees/:empId/edit
 */
app.get('/employees/:empId/edit', async (req, res) => {
    try {
        const empId = req.params.empId
        const employee = await business.getEmployeeById(empId)
        
        if (!employee) {
            return res.status(404).send('Employee not found')
        }
        
        res.render('edit-employee', { employee })
    } catch (error) {
        res.status(500).send('Error loading edit form: ' + error.message)
    }
})

/**
 * Update employee
 * @route POST /employees/:empId/edit
 */
app.post('/employees/:empId/edit', async (req, res) => {
    try {
        const empId = req.params.empId
        const { name, phone } = req.body
        
        // Trim inputs
        const trimmedName = name ? name.trim() : ''
        const trimmedPhone = phone ? phone.trim() : ''
        
        // Validation
        const phoneRegex = /^\d{4}-\d{4}$/
        
        if (!trimmedName) {
            return res.send('Error: Name cannot be empty')
        }
        
        if (!phoneRegex.test(trimmedPhone)) {
            return res.send('Error: Phone must be in format 1234-5678')
        }
        
        // Update employee
        const updated = await business.updateEmployee(empId, {
            name: trimmedName,
            phone: trimmedPhone
        })
        
        if (!updated) {
            return res.status(404).send('Employee not found')
        }
        
        // PRG pattern - redirect to landing page
        res.redirect('/')
    } catch (error) {
        res.status(500).send('Error updating employee: ' + error.message)
    }
})

/**
 * Start the server
 */
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`)
})