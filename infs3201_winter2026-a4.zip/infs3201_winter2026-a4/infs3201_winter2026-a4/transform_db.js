const { MongoClient, ObjectId } = require("mongodb");

const uri = "mongodb+srv://60104296:Alyafei304@cluster0.tftarqy.mongodb.net/infs3201_winter2026?retryWrites=true&w=majority";
const client = new MongoClient(uri);

async function transform() {
    await client.connect();
    const db = client.db("infs3201_winter2026");

    const shifts = db.collection("shifts");
    const assignments = db.collection("assignments");
    const employees = db.collection("employees");

    console.log("Step 1: Add employees array");

    await shifts.updateMany({}, {
        $set: { employees: [] }
    });

    console.log("Step 2: Embed employees");

    const allAssignments = await assignments.find().toArray();

    for (let i = 0; i < allAssignments.length; i++) {
        let a = allAssignments[i];

        let emp = await employees.findOne({ employeeId: a.employeeId });
        let shift = await shifts.findOne({ shiftId: a.shiftId });

        if (emp && shift) {
            await shifts.updateOne(
                { _id: shift._id },
                { $push: { employees: emp._id } }
            );
        }
    }

    console.log("Step 3: DONE embedding");

    console.log("NOW go to MongoDB Compass and:");
    console.log("- delete assignments collection");
    console.log("- remove employeeId field");
    console.log("- remove shiftId field");

    await client.close();
}

transform();