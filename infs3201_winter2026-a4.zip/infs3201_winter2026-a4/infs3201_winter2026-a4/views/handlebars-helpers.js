/**
 * Check if a time is before 12:00 PM (morning)
 * @param {string} time - Time in HH:MM format
 * @returns {boolean}
 */
function isMorning(time) {
    const hour = parseInt(time.split(':')[0], 10)
    return hour < 12
}

module.exports = {
    isMorning
}