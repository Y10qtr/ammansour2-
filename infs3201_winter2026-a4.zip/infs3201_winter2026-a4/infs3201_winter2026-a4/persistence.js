const { MongoClient } = require('mongodb')

const url = 'mongodb://localhost:27017'
const dbName = 'infs3201_winter2026'
let db = null

/**
 * Connect to MongoDB
 * @returns {Promise<Db>}
 */
async function connect() {
    if (db) return db
    
    try {
        const client = new MongoClient(url)
        await client.connect()
        console.log('Connected successfully to MongoDB')
        db = client.db(dbName)
        return db
    } catch (error) {
        console.error('MongoDB connection error:', error)
        throw error
    }
}

/**
 * Return a list of all employees loaded from the storage.
 * @returns {Promise<Array<{ employeeId: string, name: string, phone: string }>>}
 */
async function getAllEmployees() {
    const database = await connect()
    const collection = database.collection('employees')
    return await collection.find({}).toArray()
}

/**
 * Find a single employee given their ID number.
 * @param {string} empId 
 * @returns {Promise<{ employeeId: string, name: string, phone: string }|null>}
 */
async function findEmployee(empId) {
    const database = await connect()
    const collection = database.collection('employees')
    return await collection.findOne({ employeeId: empId })
}

/**
 * Get a list of shift details for an employee.
 * @param {string} empId 
 * @returns {Promise<Array<{shiftId:string, date:string, startTime:string, endTime:string}>>}
 */
async function getEmployeeShifts(empId) {
    const database = await connect()
    
    const assignmentsCollection = database.collection('assignments')
    const assignments = await assignmentsCollection.find({ employeeId: empId }).toArray()
    
    if (assignments.length === 0) {
        return []
    }
    
    const shiftIds = assignments.map(a => a.shiftId)
    
    const shiftsCollection = database.collection('shifts')
    const shifts = await shiftsCollection.find({ shiftId: { $in: shiftIds } }).toArray()
    
    shifts.sort((a, b) => {
        if (a.date < b.date) return -1
        if (a.date > b.date) return 1
        if (a.startTime < b.startTime) return -1
        if (a.startTime > b.startTime) return 1
        return 0
    })

    return shifts
}

/**
 * Add a new employee record to the system.
 * @param {{name:string, phone:string}} emp 
 * @returns {Promise<{employeeId: string, name: string, phone: string}>}
 */
async function addEmployeeRecord(emp) {
    const database = await connect()
    const collection = database.collection('employees')
    
    const allEmployees = await collection.find({}).toArray()
    let maxId = 0
    
    for (let e of allEmployees) {
        let eid = Number(e.employeeId.slice(1))
        if (eid > maxId) {
            maxId = eid
        }
    }
    
    const newEmployee = {
        employeeId: `E${String(maxId + 1).padStart(3, '0')}`,
        name: emp.name,
        phone: emp.phone
    }
    
    await collection.insertOne(newEmployee)
    return newEmployee
}

/**
 * Update an employee record
 * @param {string} empId 
 * @param {{name: string, phone: string}} empData 
 * @returns {Promise<boolean>}
 */
async function updateEmployee(empId, empData) {
    const database = await connect()
    const collection = database.collection('employees')
    
    const result = await collection.updateOne(
        { employeeId: empId },
        { $set: { name: empData.name, phone: empData.phone } }
    )
    
    return result.modifiedCount > 0
}

/**
 * Initialize database with data from JSON files
 * @returns {Promise<void>}
 */
async function initializeDatabase() {
    const database = await connect()
    const fs = require('fs/promises')
    
    await database.collection('employees').deleteMany({})
    await database.collection('shifts').deleteMany({})
    await database.collection('assignments').deleteMany({})
    
    const employeesData = JSON.parse(await fs.readFile('employees.json'))
    const shiftsData = JSON.parse(await fs.readFile('shifts.json'))
    const assignmentsData = JSON.parse(await fs.readFile('assignments.json'))
    
    if (employeesData.length > 0) {
        await database.collection('employees').insertMany(employeesData)
    }
    
    if (shiftsData.length > 0) {
        await database.collection('shifts').insertMany(shiftsData)
    }
    
    if (assignmentsData.length > 0) {
        await database.collection('assignments').insertMany(assignmentsData)
    }
    
    console.log('Database initialized with sample data')
}

module.exports = {
    getAllEmployees, findEmployee, getEmployeeShifts,
    addEmployeeRecord, updateEmployee, initializeDatabase
}